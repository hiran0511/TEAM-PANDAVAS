# scripts/rainfall_prediction.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from statsmodels.tsa.arima.model import ARIMA
import numpy as np
from tensorflow.keras.models import Sequential # type: ignore
from tensorflow.keras.layers import LSTM, Dense # type: ignore
import joblib

# -----------------------------
# Step 1: Load dataset
# -----------------------------
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "rainfall_2022_2024.csv")

data = pd.read_csv(DATA_PATH)

# Clean column names
data.columns = data.columns.str.strip().str.replace(' ', '_').str.lower()

# Ensure date column is datetime
data['date'] = pd.to_datetime(data['date'])

print("Available Cities:", data['city'].unique())

# -----------------------------
# Step 2: Ask user for city input
# -----------------------------
city_name = input("Enter the city name: ").strip()

if city_name not in data['city'].unique():
    print(f"City '{city_name}' not found! Please choose from: {data['city'].unique()}")
    exit()

# Filter data for chosen city
city_data = data[data['city'] == city_name].sort_values('date')

# -----------------------------
# Step 3: Visualization
# -----------------------------
rainfall_column = 'rainfall_mm'

# Seaborn static plot
plt.figure(figsize=(12,6))
sns.lineplot(x='date', y=rainfall_column, data=city_data)
plt.title(f'Rainfall Trend in {city_name}')
plt.xlabel('Date')
plt.ylabel('Rainfall (mm)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Plotly interactive plot
fig = px.lineplot(city_data, x='date', y=rainfall_column, title=f'Rainfall Trend in {city_name}')
fig.show()

# -----------------------------
# Step 4: ARIMA Forecast
# -----------------------------
rainfall_series = city_data[rainfall_column]

# Train ARIMA model
model_arima = ARIMA(rainfall_series, order=(5,1,0))
model_fit = model_arima.fit()

# Forecast next 7 days
forecast = model_fit.forecast(steps=7)
last_date = city_data['date'].max()
forecast_dates = [last_date + pd.Timedelta(days=i) for i in range(1, 8)]

forecast_df = pd.DataFrame({
    'date': forecast_dates,
    'forecasted_rainfall_mm': forecast
})

print(f"\n7-Day Rainfall Forecast (ARIMA) for {city_name}:")
print(forecast_df)

# -----------------------------
# Step 5: LSTM Forecast
# -----------------------------
def create_sequences(data, seq_length):
    X, y = [], []
    for i in range(len(data)-seq_length):
        X.append(data[i:i+seq_length])
        y.append(data[i+seq_length])
    return np.array(X), np.array(y)

seq_length = 7
rainfall_values = city_data[rainfall_column].values
X, y = create_sequences(rainfall_values, seq_length)
X = X.reshape((X.shape[0], X.shape[1], 1))

# Build LSTM model
model_lstm = Sequential()
model_lstm.add(LSTM(50, activation='relu', input_shape=(seq_length, 1)))
model_lstm.add(Dense(1))
model_lstm.compile(optimizer='adam', loss='mse')
model_lstm.fit(X, y, epochs=50, batch_size=16, verbose=0)

# Predict next 7 days (rolling prediction)
predictions = []
last_seq = rainfall_values[-seq_length:].reshape((1, seq_length, 1))
for _ in range(7):
    pred = model_lstm.predict(last_seq, verbose=0)[0][0]
    predictions.append(pred)
    # Update last_seq
    new_seq = np.append(last_seq.flatten()[1:], pred).reshape((1, seq_length, 1))
    last_seq = new_seq

forecast_lstm_df = pd.DataFrame({
    'date': forecast_dates,
    'forecasted_rainfall_mm': predictions
})

print(f"\n7-Day Rainfall Prediction (LSTM) for {city_name}:")
print(forecast_lstm_df)

# -----------------------------
# Step 6: Save models
# -----------------------------
joblib.dump(model_fit, f'../models/arima_rainfall_model_{city_name.lower()}.pkl')
model_lstm.save(f'../models/lstm_rainfall_model_{city_name.lower()}.h5')

print("\nModels saved successfully!")